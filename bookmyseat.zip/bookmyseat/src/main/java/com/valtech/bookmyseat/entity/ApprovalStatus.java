package com.valtech.bookmyseat.entity;

public enum ApprovalStatus {
	APPROVED, REJECTED, PENDING
}
