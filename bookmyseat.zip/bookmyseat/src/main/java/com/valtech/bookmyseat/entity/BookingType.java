package com.valtech.bookmyseat.entity;

public enum BookingType {
	DAILY, WEEKLY, MONTHLY, CUSTOM_DATE
}
