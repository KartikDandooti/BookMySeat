package com.valtech.bookmyseat.entity;

public enum ParkingType {
	TWO_WHEELER, FOUR_WHEELER
}
