package com.valtech.bookmyseat.entity;

public enum TeaAndCoffee {
	TEA, COFFEE
}