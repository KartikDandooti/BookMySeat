package com.valtech.bookmyseat.model;

public class LoginResponse {
	@SuppressWarnings("unused")
	private String message;
	@SuppressWarnings("unused")
	private String role;
}
