INSERT INTO role (role_name) VALUES 
('ADMIN'),
('USER'),
('SECURITY');