INSERT INTO shift (created_by, created_date, end_time, modified_by, modified_date, shift_name, start_time) VALUES
(5716, '2024-02-15', '18:00:00', 5716, '2024-02-15', 'Morning', '09:00:00'),
(5716, '2024-02-15', '19:00:00', 5716, '2024-02-15', 'Afternoon', '10:00:00');
