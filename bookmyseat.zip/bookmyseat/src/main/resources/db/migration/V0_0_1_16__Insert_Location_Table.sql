INSERT INTO location (location_name) VALUES 
('BENGALURU');