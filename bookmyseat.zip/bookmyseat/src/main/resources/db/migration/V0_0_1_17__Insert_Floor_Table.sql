INSERT INTO floor (floor_name, location_id) VALUES 
('GROUND FLOOR', 1),
('MEZZANINE FLOOR', 1),
('1ST FLOOR', 1),
('2ND FLOOR', 1),
('3RD FLOOR', 1),
('TRAINING ROOM', 1);