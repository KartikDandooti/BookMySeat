INSERT INTO project (created_by, created_date, modified_by, modified_date, project_name)
VALUES 
  (5716, '2024-02-15', 5716, '2024-02-15', 'MENTOR MATE'),
  (5716, '2024-02-14', 5716, '2024-02-14', 'BOOK MY SEAT'),
  (5716, '2024-02-13', 5716, '2024-02-13', 'LIFE CARE'),
  (5716, '2024-02-12', 5716, '2024-02-14', 'WE CARE'),
  (5716, '2024-02-11', 5716, '2024-02-15', 'MUTUAL FUND'),
  (5716, '2024-02-11', 5716, '2024-02-15', 'RMG');