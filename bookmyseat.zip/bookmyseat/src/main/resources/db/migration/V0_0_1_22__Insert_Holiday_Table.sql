INSERT INTO holiday (holiday_id, holiday_name, holiday_date, holiday_month) VALUES
(1,'Makara Sankranthi', '2024-01-15', 'January'),
(2,'Republic Day', '2024-01-26', 'January'),
(3,'Ugadi', '2024-04-09', 'April'),
(4,'Ramadan', '2024-04-11', 'April'),
(5,'May Day', '2024-05-01', 'May'),
(6,'Independence Day', '2024-08-15', 'August'),
(7,'Gandhi Jayanti', '2024-10-02', 'October'),
(8,'Diwali', '2024-10-31', 'October'),
(9,'Kannada Rajyotsava', '2024-11-01', 'November'),
(10,'Christmas', '2024-12-25', 'December');   